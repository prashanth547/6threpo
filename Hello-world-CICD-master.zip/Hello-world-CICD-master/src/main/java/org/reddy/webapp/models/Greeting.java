package org.reddy.webapp.models;

/**
 *
 */
public class Greeting {

    /**
     *
     */
    public String getGreeting() {
        return "Hello World";
    }
}
